public class Toast {
    public String breadType = "Wheat";
    public boolean isButtered = false;
    public boolean isJammed = true;
    public byte amountOfToast = 1;
    public boolean isToasted = false;

    public boolean getToasted(){
        if(isToasted){
            System.out.println("Toast your bread.");
        }
        else{
            System.out.println("Bread is toasted.");
        }
    }

    public void toastIt(){
        isToasted = true;
    }

    public String whatBread(){
        return breadType;
    }

    public void addToast(byte x){
        amountOfToast +=x;
    }

    public boolean withJam(){
        return isJammed;
    }
}
